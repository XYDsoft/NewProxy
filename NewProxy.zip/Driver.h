//Driver.h
int DriverMain();
void setPort(int a,char * b,char * c);
void setAddrV4(void *p);
void setAddrV6(void *p);